package com.APIGateway.AG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgApplicationTests {

	@Test
	void contextLoads() {
	}

}

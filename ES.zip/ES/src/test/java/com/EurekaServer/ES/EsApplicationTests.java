package com.EurekaServer.ES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsApplicationTests {

	@Test
	void contextLoads() {
	}

}
